function mudarCor() {
    var cor = document.getElementById("body")
    if(cor.style.background == "white"){
        cor.style.background = "red"
    } else {
        cor.style.background = "white"
    }
}